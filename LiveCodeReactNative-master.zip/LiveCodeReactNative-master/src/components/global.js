module.exports = {
    addProductToCart: null,
    incrQuantity: null,
    decrQuantity: null,
    removeProduct: null,
    onSignIn: null,
    gotoSearch: null,
    setArraySearch: null
};
